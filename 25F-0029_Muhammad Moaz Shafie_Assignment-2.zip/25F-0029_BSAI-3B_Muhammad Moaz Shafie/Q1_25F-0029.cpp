#include<iostream>
#include<string>
using namespace std;

class Patient
{
public:
    string Name;
    int WaitingTime;
    Patient* Next;
    Patient(string Value)
    {
        Name = Value;
        WaitingTime = 0;
        Next = nullptr;
    }
};

class Queue
{
private:
    Patient* Front;
    Patient* Rear;
public:
    Queue()
    {
        Front = nullptr;
        Rear = nullptr;
    }
    bool IsEmpty()
    {
        return Front == nullptr;
    }
    void Enqueue(Patient* Value)
    {
        Value->Next = nullptr;
        if(Front == nullptr)
        {
            Front = Rear = Value;
        }
        else
        {
            Rear->Next = Value;
            Rear = Value;
        }
    }
    Patient* Dequeue()
    {
        if(IsEmpty())
        {
            return nullptr;
        }
        Patient* Temp = Front;
        Front = Front->Next;
        if(Front == nullptr)
        {
            Rear = nullptr;
        }
        Temp->Next = nullptr;
        return Temp;
    }
    Patient* Find(string Name)
    {
        Patient* Temp = Front;
        while(Temp != nullptr)
        {
            if(Temp->Name == Name)
            {
                return Temp;
            }
            Temp = Temp->Next;
        }
        return nullptr;
    }
    bool RemovePatient(string Name)
    {
        Patient* Current = Front;
        Patient* Previous = nullptr;
        while (Current != nullptr)
        {
            if(Current->Name == Name)
            {
                if(Previous == nullptr)
                {
                    Front = Current->Next;
                }
                else
                {
                    Previous->Next = Current->Next;
                }
                if(Current == Rear)
                {
                    Rear = Previous;
                }
                delete Current;
                return true;
            }
            Previous = Current;
            Current = Current->Next;
        }
        return false;
    }
    void IncreaseWaitingTime()
    {
        Patient* Temp = Front;
        while(Temp != nullptr)
        {
            Temp->WaitingTime++;
            Temp = Temp->Next;
        }
    }
    void PromotePatients(Queue& Destination, int Threshold, string From, string To)
    {
        Patient* Current = Front;
        Patient* Previous = nullptr;
        while(Current != nullptr)
        {
            Patient* NextPatient = Current->Next;
            if(Current->WaitingTime >= Threshold)
            {
                if(Previous == nullptr)
                {
                    Front = NextPatient;
                }
                else
                {
                    Previous->Next = NextPatient;
                }
                if(Current == Rear)
                {
                    Rear = Previous;
                }
                Current->WaitingTime = 0;
                Current->Next = nullptr;
                cout << Current->Name << " promoted " << From << " -> " << To << endl;
                Destination.Enqueue(Current);
            }
            else
            {
                Previous = Current;
            }
            Current = NextPatient;
        }
        if(Front == nullptr)
        {
            Rear = nullptr;
        }
    }
    void Display()
    {
        Patient* Temp = Front;
        cout << "[";
        while(Temp != nullptr)
        {
            cout << Temp->Name << "(" << Temp->WaitingTime << ")";
            if (Temp->Next != nullptr)
            {
                cout << ", ";
            }
            Temp = Temp->Next;
        }
        cout << "]";
    }
    ~Queue()
    {
        while(Front != nullptr)
        {
            Patient* Temp = Front;
            Front = Front->Next;
            delete Temp;
        }
        Rear = nullptr;
    }
};

class Hospital
{
private:
    Queue Q1, Q2, Q3;
    int T;
    bool PatientExists(string Name)
    {
        return Q1.Find(Name) != nullptr || Q2.Find(Name) != nullptr || Q3.Find(Name) != nullptr;
    }
    void DisplayState()
    {
        cout << "Q1=";
        Q1.Display();
        cout << " Q2=";
        Q2.Display();
        cout << " Q3=";
        Q3.Display();
        cout << endl;
    }
public:
    Hospital(int Threshold)
    {
        T = Threshold;
    }
    void Arrive(string Name, int Severity)
    {
        if(PatientExists(Name))
        {
            cout << "Patient " << Name << " is Already Waiting" << endl;
            return;
        }
        Patient* NewPatient = new Patient(Name);
        if(Severity == 1)
        {
            Q1.Enqueue(NewPatient);
            cout << Name << " Admitted to Q1" << endl;
        }
        else if(Severity == 2)
        {
            Q2.Enqueue(NewPatient);
            cout << Name << " Admitted to Q2" << endl;
        }
        else if(Severity == 3)
        {
            Q3.Enqueue(NewPatient);
            cout << Name << " Admitted to Q3" << endl;
        }
        else
        {
            cout << "Invalid Severity" << endl;
            delete NewPatient;
            return;
        }
        DisplayState();
    }
    void Tick()
    {
        Q1.IncreaseWaitingTime();
        Q2.IncreaseWaitingTime();
        Q3.IncreaseWaitingTime();
        Q2.PromotePatients(Q1, T, "Q2", "Q1");
        Q3.PromotePatients(Q2, T, "Q3", "Q2");
        DisplayState();
    }
    void Treat()
    {
        Patient* Temp = nullptr;
        if(!Q1.IsEmpty())
        {
            Temp = Q1.Dequeue();
            cout << "Treating " << Temp->Name << " (From Q1)" << endl;
        }
        else if(!Q2.IsEmpty())
        {
            Temp = Q2.Dequeue();
            cout << "Treating " << Temp->Name << " (From Q2)" << endl;
        }
        else if(!Q3.IsEmpty())
        {
            Temp = Q3.Dequeue();
            cout << "Treating " << Temp->Name << " (From Q3)" << endl;
        }
        else
        {
            cout << "No Patients Waiting" << endl;
            return;
        }
        delete Temp;
        DisplayState();
    }
    void Leave(string Name)
    {
        if(Q1.RemovePatient(Name))
        {
            cout << Name << " Left from Q1" << endl;
        }
        else if(Q2.RemovePatient(Name))
        {
            cout << Name << " Left from Q2" << endl;
        }
        else if(Q3.RemovePatient(Name))
        {
            cout << Name << " Left from Q3" << endl;
        }
        else
        {
            cout << "Patient " << Name << " Not Found" << endl;
            return;
        }
        DisplayState();
    }
};

int main()
{
    int T;
    cout << "Enter Aging Threshold T: ";
    cin >> T;
    Hospital H(T);
    string Command;
    while(cin >> Command)
    {
        if(Command == "EXIT")
        {
            break;
        }
        else if(Command == "ARRIVE")
        {
            string Name;
            int Severity;
            cin >> Name >> Severity;
            cout << ">> ARRIVE " << Name << " " << Severity << endl;
            H.Arrive(Name, Severity);
        }
        else if(Command == "TICK")
        {
            cout << ">> TICK" << endl;
            H.Tick();
        }
        else if(Command == "TREAT")
        {
            cout << ">> TREAT" << endl;
            H.Treat();
        }
        else if(Command == "LEAVE")
        {
            string Name;
            cin >> Name;
            cout << ">> LEAVE" << Name << endl;
            H.Leave(Name);
        }
    }

	system("pause");
    return 0;
}