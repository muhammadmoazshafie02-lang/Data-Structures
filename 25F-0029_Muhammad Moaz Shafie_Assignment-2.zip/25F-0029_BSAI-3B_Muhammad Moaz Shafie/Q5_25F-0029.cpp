#include<iostream>
using namespace std;

template<class T>
class Stack
{
private:
    T* Arr;
    int Capacity;
    int TopIndex;
public:
    Stack(int Size)
    {
        Capacity = Size;
        Arr = new T[Capacity];
        TopIndex = -1;
    }
    bool Push(T Data)
    {
        if (IsFull())
        {
            return false;
        }
        Arr[++TopIndex] = Data;
        return true;
    }
    bool Pop(T& Data)
    {
        if (IsEmpty())
        {
            return false;
        }
        Data = Arr[TopIndex--];
        return true;
    }
    bool Top(T& Data)
    {
        if (IsEmpty())
        {
            return false;
        }
        Data = Arr[TopIndex];
        return true;
    }
    bool IsEmpty()
    {
        return TopIndex == -1;
    }
    bool IsFull()
    {
        return TopIndex == Capacity - 1;
    }
    bool Display()
    {
        if (IsEmpty())
        {
            return false;
        }
        for (int i = TopIndex; i >= 0; i--)
        {
            cout << Arr[i] << endl;
        }
        return true;
    }
    bool Size(int& Count)
    {
        Count = TopIndex + 1;
        return true;
    }
    bool Search(T Data, int& Position)
    {
        for (int i = TopIndex; i >= 0; i--)
        {
            if (Arr[i] == Data)
            {
                Position = TopIndex - i + 1;
                return true;
            }
        }
        return false;
    }
    bool Clear()
    {
        TopIndex = -1;
        return true;
    }
    bool ReplaceTop(T Data)
    {
        if (IsEmpty())
        {
            return false;
        }
        Arr[TopIndex] = Data;
        return true;
    }
    bool SwapTopTwo()
    {
        if (TopIndex < 1)
        {
            return false;
        }
        T Temp = Arr[TopIndex];
        Arr[TopIndex] = Arr[TopIndex - 1];
        Arr[TopIndex - 1] = Temp;
        return true;
    }
    bool DuplicateTop()
    {
        if (IsEmpty() || IsFull())
        {
            return false;
        }
        Arr[TopIndex + 1] = Arr[TopIndex];
        TopIndex++;
        return true;
    }
    bool CountOccurrences(T Data, int& Count)
    {
        Count = 0;
        for (int i = 0; i <= TopIndex; i++)
        {
            if (Arr[i] == Data)
            {
                Count++;
            }
        }
        return true;
    }
    bool RemoveAll(T Data, int& RemovedCount)
    {
        RemovedCount = 0;
        int Index = 0;
        for (int i = 0; i <= TopIndex; i++)
        {
            if (Arr[i] == Data)
            {
                RemovedCount++;
            }
            else
            {
                Arr[Index++] = Arr[i];
            }
        }
        TopIndex = Index - 1;
        return true;
    }
    ~Stack()
    {
        delete[] Arr;
    }
};

int main()
{
    int Capacity;
    cout << "Enter Stack Capacity: ";
    cin >> Capacity;
    if (Capacity <= 0)
    {
        cout << "Invalid Capacity" << endl;
        return 0;
    }
    Stack<int> S(Capacity);
    int Choice, Data, Count, Position;
    do
    {
        cout << "\n1. Push 2. Pop 3. Top 4. IsEmpty 5. IsFull 6. Display 7. Size 8. Search 9. Clear 10. ReplaceTop 11. SwapTopTwo\n12. DuplicateTop 13. CountOccurrences 14. RemoveAll 0. Exit\n";
        cout << "Enter Choice: ";
        cin >> Choice;
        switch (Choice)
        {
        case 1:
            cout << "Enter Value: ";
            cin >> Data;
            cout << (S.Push(Data) ? "Push Successful" : "Stack Overflow") << endl;
            break;
        case 2:
            if (S.Pop(Data))
            {
                cout << "Popped: " << Data << endl;
            }
            else
            {
                cout << "Stack Underflow" << endl;
            }
            break;
        case 3:
            if (S.Top(Data))
            {
                cout << "Top: " << Data << endl;
            }
            else
            {
                cout << "Stack is Empty" << endl;
            }
            break;
        case 4:
            cout << (S.IsEmpty() ? "Stack is Empty" : "Stack is Not Empty") << endl;
            break;
        case 5:
            cout << (S.IsFull() ? "Stack is Full" : "Stack is Not Full") << endl;
            break;
        case 6:
            if (!S.Display())
            {
                cout << "Stack is Empty" << endl;
            }
            break;
        case 7:
            S.Size(Count);
            cout << "Size: " << Count << endl;
            break;
        case 8:
            cout << "Enter Value: ";
            cin >> Data;
            if (S.Search(Data, Position))
            {
                cout << "Position From Top: " << Position << endl;
            }
            else
            {
                cout << "Element Not Found" << endl;
            }
            break;
        case 9:
            S.Clear();
            cout << "Stack Cleared" << endl;
            break;
        case 10:
            cout << "Enter Value: ";
            cin >> Data;
            cout << (S.ReplaceTop(Data) ? "Top Replaced" : "Stack is Empty") << endl;
            break;
        case 11:
            cout << (S.SwapTopTwo() ? "Top Two Elements Swapped" : "At least Two Elements are Required") << endl;
            break;
        case 12:
            cout << (S.DuplicateTop() ? "Top Duplicated" : "Stack is Empty or Full") << endl;
            break;
        case 13:
            cout << "Enter Value: ";
            cin >> Data;
            S.CountOccurrences(Data, Count);
            cout << "Occurrences: " << Count << endl;
            break;
        case 14:
            cout << "Enter Value: ";
            cin >> Data;
            S.RemoveAll(Data, Count);
            cout << "Removed: " << Count << endl;
            break;
        case 0:
            break;
        default:
            cout << "Invalid Choice" << endl;
        }
    } while (Choice != 0);

	system("pause");
    return 0;
}