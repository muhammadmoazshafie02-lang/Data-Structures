#include<iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* next;
    Node(int value)
    {
        data = value;
        next = NULL;
    }
};
class LinkedList
{
private:
    Node* head;
public:
    LinkedList()
    {
        head = NULL;
    }
    void insert(int value)
    {
        Node* new_node = new Node(value);
        if (head == NULL)
        {
            head = new_node;
        }
        else
        {
            Node* temp = head;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = new_node;
        }
    }
    void display()
    {
        Node* temp = head;
        while (temp != NULL)
        {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
    void reverse(int a, int b)
    {
        if (head == NULL || a == b)
        {
            return;
        }
        Node* previous = NULL;
        Node* current = head;
        for (int i = 1; i < a; i++)
        {
            previous = current;
            current = current->next;
        }

        Node* first = current;
        Node* nextNode = NULL;
        Node* before = previous;

        for (int i = a; i <= b; i++)
        {
            nextNode = current->next;
            current->next = previous;
            previous = current;
            current = nextNode;
        }
        if (before != NULL)
        {
            before->next = previous;
        }
        else
        {
            head = previous;
        }
        first->next = current;
    }
};

int main()
{
    LinkedList list;
    int value;
    cout << "Enter the Elements of the Linked List Separated by Space:" << endl;
    while (cin >> value)
    {
        list.insert(value);
        if (cin.peek() == '\n')
        {
            break;
        }
    }

    cout << "Linked List Before Reversal:" << endl;
    list.display();

    int a, b;

    cout << "Enter Starting Position (a): ";
    cin >> a;

    cout << "Enter Ending Position (b): ";
    cin >> b;

    list.reverse(a, b);

    cout << "Linked List After Reversal:" << endl;
    list.display();

    system("pause");
    return 0;
}

/*
First, I move the `current` pointer to position `a`. Then I reverse the
nodes from position `a` to `b` by changing their `next` pointers. I also 
keep track of the node before `a` so I can connect it with the new first 
node of the reversed part. At the end, I connect the old first node of the 
reversed part to the node after position `b`. The list is reversed in-place, 
so no new linked list is created.
*/