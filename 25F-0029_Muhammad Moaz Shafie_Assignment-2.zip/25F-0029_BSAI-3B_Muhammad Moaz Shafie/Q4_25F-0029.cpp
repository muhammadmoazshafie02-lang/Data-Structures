//#include<iostream>
//#include<string>
//using namespace std;
//
//class Message
//{
//public:
//    int Start;
//    int Length;
//    Message()
//    {
//        Start = 0;
//        Length = 0;
//    }
//    Message(int S, int L)
//    {
//        Start = S;
//        Length = L;
//    }
//};
//
//class Buffer
//{
//private:
//    char* Data;
//    Message* Messages;
//    int B;
//    int Used;
//    int Count;
//    int WritePos;
//    int Front;
//    int Rear;
//    char GetChar(int Pos)
//    {
//        return Data[Pos % B];
//    }
//    void StoreChar(int Pos, char Value)
//    {
//        Data[Pos % B] = Value;
//    }
//    string GetMessage(Message M)
//    {
//        string Text = "";
//        for (int i = 0; i < M.Length; i++)
//        {
//            Text = Text + GetChar(M.Start + i);
//        }
//        return Text;
//    }
//    void RemoveOldest(bool Show)
//    {
//        Message Temp = Messages[Front];
//        if (Show)
//        {
//            cout << "Evicted: " << GetMessage(Temp) << endl;
//        }
//        Used = Used - (Temp.Length + 1);
//        Front = (Front + 1) % B;
//        Count--;
//    }
//public:
//    Buffer(int Size)
//    {
//        B = Size;
//        Data = new char[B];
//        Messages = new Message[B];
//        Used = 0;
//        Count = 0;
//        WritePos = 0;
//        Front = 0;
//        Rear = 0;
//    }
//    void Write(string Text)
//    {
//        int Need = Text.length() + 1;
//        if (Need > B)
//        {
//            cout << "Rejected: Record Needs " << Need << " bytes, Capacity is " << B << endl;
//            return;
//        }
//        while (B - Used < Need)
//        {
//            cout << "Evicted: " << GetMessage(Messages[Front]) << endl;
//            RemoveOldest(false);
//        }
//        int Start = WritePos;
//        for (int i = 0; i < Text.length(); i++)
//        {
//            StoreChar(WritePos, Text[i]);
//            WritePos = (WritePos + 1) % B;
//        }
//        StoreChar(WritePos, '\0');
//        WritePos = (WritePos + 1) % B;
//        Messages[Rear] = Message(Start, Text.length());
//        Rear = (Rear + 1) % B;
//        Used = Used + Need;
//        Count++;
//        cout << "Stored (Used " << Used << "/" << B << ")" << endl;
//    }
//    void Read()
//    {
//        if (Count == 0)
//        {
//            cout << "No Messages" << endl;
//            return;
//        }
//        cout << GetMessage(Messages[Front]) << endl;
//        RemoveOldest(false);
//    }
//    void Dump()
//    {
//        int Number = 1;
//        for (int i = 0; i < Count; i++)
//        {
//            int Pos = (Front + i) % B;
//            cout << Number << ": " << GetMessage(Messages[Pos]) << endl;
//            Number++;
//        }
//    }
//    void Status()
//    {
//        cout << "Messages=" << Count << " Used=" << Used << " Free=" << B - Used << endl;
//    }
//    ~Buffer()
//    {
//        delete[] Messages;
//        delete[] Data;
//    }
//};
//
//int main()
//{
//    int B;
//    cout << ">> Enter Buffer Size B: ";
//    cin >> B;
//    cin.ignore();
//    Buffer Box(B);
//    string Command;
//    while (getline(cin, Command))
//    {
//        if (Command == "EXIT")
//        {
//            break;
//        }
//        else if (Command.substr(0, 6) == "WRITE ")
//        {
//            string Text = Command.substr(6);
//            cout << ">> WRITE " << Text << endl;
//            Box.Write(Text);
//        }
//        else if (Command == "READ")
//        {
//            cout << ">> READ" << endl;
//            Box.Read();
//        }
//        else if (Command == "DUMP")
//        {
//            cout << ">> DUMP" << endl;
//            Box.Dump();
//        }
//        else if (Command == "STATUS")
//        {
//            cout << ">> STATUS" << endl;
//            Box.Status();
//        }
//    }
//
//    system("pause");
//    return 0;
//}