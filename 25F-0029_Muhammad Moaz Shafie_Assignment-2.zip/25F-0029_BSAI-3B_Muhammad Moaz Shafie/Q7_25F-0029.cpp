#include<iostream>
#include<string>
#include<cstdlib>
#include<ctime>
using namespace std;

class Tab
{
public:
    string WebsiteURL;
    int BrowserCode;
    int TabCategory;
    int TabId;
    Tab* Next;
    Tab(string URL, int Browser, int Category, int ID)
    {
        WebsiteURL = URL;
        BrowserCode = Browser;
        TabCategory = Category;
        TabId = ID;
        Next = nullptr;
    }
    void Display()
    {
        cout << "Tab ID: " << TabId << " | URL: " << WebsiteURL << " | Browser: " << BrowserCode << " | Category: " << TabCategory << endl;
    }
};

class Stack
{
private:
    Tab* Top;
    int Count;
public:
    Stack()
    {
        Top = nullptr;
        Count = 0;
    }
    bool IsEmpty()
    {
        return Top == nullptr;
    }
    void Push(Tab* Value)
    {
        Value->Next = Top;
        Top = Value;
        Count++;
    }
    Tab* Pop()
    {
        if (IsEmpty())
        {
            return nullptr;
        }
        Tab* Temp = Top;
        Top = Top->Next;
        Temp->Next = nullptr;
        Count--;
        return Temp;
    }
    Tab* Peek()
    {
        return Top;
    }
    int CountTabs()
    {
        return Count;
    }
    ~Stack()
    {
        while (Top != nullptr)
        {
            Tab* Temp = Top;
            Top = Top->Next;
            delete Temp;
        }
    }
};

class Browser
{
private:
    Stack S[5];
    int NextID;
    bool ValidStack(int StackNo)
    {
        return StackNo >= 1 && StackNo <= 5;
    }
    Tab* FindTab(int ID, int& StackNo, int& Above)
    {
        for (int i = 0; i < 5; i++)
        {
            Stack Temp;
            Above = 0;
            while (!S[i].IsEmpty())
            {
                Tab* T = S[i].Pop();
                Temp.Push(T);
                if (T->TabId == ID)
                {
                    StackNo = i + 1;
                    while (!Temp.IsEmpty())
                    {
                        S[i].Push(Temp.Pop());
                    }
                    return T;
                }
                Above++;
            }
            while (!Temp.IsEmpty())
            {
                S[i].Push(Temp.Pop());
            }
        }
        return nullptr;
    }
    void DisplayState()
    {
        DisplayAllStacks();
    }
public:
    Browser()
    {
        NextID = 1;
        srand(time(0));
    }
    void push(string URL, int BrowserCode, int Category)
    {
        int StackNo = rand() % 5;
        Tab* T = new Tab(URL, BrowserCode, Category, NextID++);
        S[StackNo].Push(T);
        cout << "Opened in Stack " << StackNo + 1 << endl;
        T->Display();
        DisplayState();
    }
    void Pop(int StackNo)
    {
        if (!ValidStack(StackNo))
        {
            cout << "Invalid Stack Number" << endl;
            return;
        }
        Tab* T = S[StackNo - 1].Pop();
        if (T == nullptr)
        {
            cout << "Stack is Empty" << endl;
        }
        else
        {
            cout << "Closed Tab:" << endl;
            T->Display();
            delete T;
        }
        DisplayState();
    }
    void Search(int ID)
    {
        int StackNo = 0, Above = 0;
        Tab* T = FindTab(ID, StackNo, Above);
        if (T == nullptr)
        {
            cout << "Tab Not Found" << endl;
        }
        else
        {
            T->Display();
            cout << "Stack: " << StackNo << " Tabs Above: " << Above << endl;
        }
    }
    void CloseTab(int ID)
    {
        int StackNo = 0, Above = 0;
        Tab* T = FindTab(ID, StackNo, Above);
        if (T == nullptr)
        {
            cout << "Tab Not Found" << endl;
            return;
        }
        Stack Temp;
        for (int i = 0; i < Above; i++)
        {
            Temp.Push(S[StackNo - 1].Pop());
        }
        Tab* Closed = S[StackNo - 1].Pop();
        while (!Temp.IsEmpty())
        {
            S[StackNo - 1].Push(Temp.Pop());
        }
        cout << "Closed Tab:" << endl;
        Closed->Display();
        cout << "Temporarily Removed: " << Above << endl;
        delete Closed;
        DisplayState();
    }
    void Peek(int StackNo)
    {
        if (!ValidStack(StackNo))
        {
            cout << "Invalid Stack Number" << endl;
            return;
        }
        Tab* T = S[StackNo - 1].Peek();
        if (T == nullptr)
        {
            cout << "Stack is Empty" << endl;
        }
        else
        {
            T->Display();
        }
    }
    int CountTabs(int StackNo)
    {
        if (!ValidStack(StackNo))
        {
            cout << "Invalid Stack Number" << endl;
            return 0;
        }
        return S[StackNo - 1].CountTabs();
    }
    void DisplayStack(int StackNo)
    {
        if (!ValidStack(StackNo))
        {
            cout << "Invalid Stack Number" << endl;
            return;
        }
        Stack Temp;
        cout << "Stack " << StackNo << ":" << endl;
        while (!S[StackNo - 1].IsEmpty())
        {
            Tab* T = S[StackNo - 1].Pop();
            T->Display();
            Temp.Push(T);
        }
        while (!Temp.IsEmpty())
        {
            S[StackNo - 1].Push(Temp.Pop());
        }
    }
    void DisplayAllStacks()
    {
        for (int i = 1; i <= 5; i++)
        {
            DisplayStack(i);
        }
    }
    void MoveTab(int ID, int Destination)
    {
        if (!ValidStack(Destination))
        {
            cout << "Invalid Destination Stack" << endl;
            return;
        }
        int StackNo = 0, Above = 0;
        Tab* T = FindTab(ID, StackNo, Above);
        if (T == nullptr)
        {
            cout << "Tab Not Found" << endl;
            return;
        }
        if (StackNo == Destination)
        {
            cout << "Tab is Already in the Destination Stack" << endl;
            return;
        }
        Stack Temp;
        for (int i = 0; i < Above; i++)
        {
            Temp.Push(S[StackNo - 1].Pop());
        }
        Tab* Moving = S[StackNo - 1].Pop();
        while (!Temp.IsEmpty())
        {
            S[StackNo - 1].Push(Temp.Pop());
        }
        S[Destination - 1].Push(Moving);
        cout << "Moved Tab:" << endl;
        Moving->Display();
        DisplayState();
    }
    void ClearStack(int StackNo)
    {
        if (!ValidStack(StackNo))
        {
            cout << "Invalid Stack Number" << endl;
            return;
        }
        while (!S[StackNo - 1].IsEmpty())
        {
            Tab* T = S[StackNo - 1].Pop();
            T->Display();
            delete T;
        }
        DisplayState();
    }
    void FindTabsByBrowser(int BrowserCode)
    {
        bool Found = false;
        for (int i = 0; i < 5; i++)
        {
            Stack Temp;
            int Position = 1;
            while (!S[i].IsEmpty())
            {
                Tab* T = S[i].Pop();
                Temp.Push(T);
                if (T->BrowserCode == BrowserCode)
                {
                    T->Display();
                    cout << "Stack: " << i + 1 << " Position from Top: " << Position << endl;
                    Found = true;
                }
                Position++;
            }
            while (!Temp.IsEmpty())
            {
                S[i].Push(Temp.Pop());
            }
        }
        if (!Found)
        {
            cout << "No Tabs Found" << endl;
        }
    }
    int CountTotalTabs()
    {
        int Total = 0;
        for (int i = 0; i < 5; i++)
        {
            Total = Total + S[i].CountTabs();
        }
        return Total;
    }
};

int main()
{
    Browser B;
    int Choice, StackNo, ID, BrowserCode, Category, Destination;
    string URL;
    do
    {
        cout << "\n1. Open Tab 2. Pop Tab 3. Search Tab 4. Close Tab 5. Peek 6. Count Tabs 7. Display Stack 8. Display All Stacks\n9. Move Tab 10. Clear Stack 11. Find Tabs By Browser 12. Count Total Tabs 0. Exit\n";
        cout << "Enter Choice: ";
        cin >> Choice;
        switch (Choice)
        {
        case 1:
            cout << "Enter URL: ";
            cin >> URL;
            cout << "Enter Browser Code: ";
            cin >> BrowserCode;
            cout << "Enter Category: ";
            cin >> Category;
            B.push(URL, BrowserCode, Category);
            break;
        case 2:
            cout << "Enter Stack Number: ";
            cin >> StackNo;
            B.Pop(StackNo);
            break;
        case 3:
            cout << "Enter Tab ID: ";
            cin >> ID;
            B.Search(ID);
            break;
        case 4:
            cout << "Enter Tab ID: ";
            cin >> ID;
            B.CloseTab(ID);
            break;
        case 5:
            cout << "Enter Stack Number: ";
            cin >> StackNo;
            B.Peek(StackNo);
            break;
        case 6:
            cout << "Enter Stack Number: ";
            cin >> StackNo;
            cout << "Total Tabs: " << B.CountTabs(StackNo) << endl;
            break;
        case 7:
            cout << "Enter Stack Number: ";
            cin >> StackNo;
            B.DisplayStack(StackNo);
            break;
        case 8:
            B.DisplayAllStacks();
            break;
        case 9:
            cout << "Enter Tab ID: ";
            cin >> ID;
            cout << "Enter Destination Stack: ";
            cin >> Destination;
            B.MoveTab(ID, Destination);
            break;
        case 10:
            cout << "Enter Stack Number: ";
            cin >> StackNo;
            B.ClearStack(StackNo);
            break;
        case 11:
            cout << "Enter Browser Code: ";
            cin >> BrowserCode;
            B.FindTabsByBrowser(BrowserCode);
            break;
        case 12:
            cout << "Total Open Tabs: " << B.CountTotalTabs() << endl;
            break;
        case 0:
            break;
        default:
            cout << "Invalid Choice" << endl;
        }
    } while (Choice != 0);

	system("pause");
    return 0;
}