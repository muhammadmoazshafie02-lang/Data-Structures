#include<iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* next;
    Node* prev;
    Node(int value)
    {
        data = value;
        next = NULL;
        prev = NULL;
    }
};
class LinkedList
{
private:
    Node* head;
public:
    LinkedList()
    {
        head = NULL;
    }
    void insert(int value)
    {
        Node* new_node = new Node(value);
        if (head == NULL)
        {
            head = new_node;
            new_node->next = head;
            new_node->prev = head;
        }
        else
        {
            Node* last = head->prev;

            new_node->next = head;
            new_node->prev = last;

            last->next = new_node;
            head->prev = new_node;
        }
    }
    void display()
    {
        if (head == NULL)
        {
            cout << "NULL" << endl;
            return;
        }
        Node* temp = head;
        do
        {
            cout << temp->data << " <-> ";
            temp = temp->next;
        } while (temp != head);
        cout << "HEAD" << endl;
    }
    void swap_nodes(int value1, int value2)
    {
        if (head == NULL || value1 == value2)
        {
            return;
        }
        Node* first = head;
        Node* second = head;
        do
        {
            if (first->data == value1)
            {
                break;
            }
            first = first->next;
        } while (first != head);
        do
        {
            if (second->data == value2)
            {
                break;
            }
            second = second->next;
        } while (second != head);
        if (first->data != value1 || second->data != value2)
        {
            return;
        }
        Node* first_prev = first->prev;
        Node* first_next = first->next;
        Node* second_prev = second->prev;
        Node* second_next = second->next;
        if (first->next == second)
        {
            first_prev->next = second;
            second->prev = first_prev;

            second->next = first;
            first->prev = second;

            first->next = second_next;
            second_next->prev = first;
        }
        else if (second->next == first)
        {
            second_prev->next = first;
            first->prev = second_prev;

            first->next = second;
            second->prev = first;

            second->next = first_next;
            first_next->prev = second;
        }
        else
        {
            first_prev->next = second;
            second->prev = first_prev;

            second->next = first_next;
            first_next->prev = second;

            second_prev->next = first;
            first->prev = second_prev;

            first->next = second_next;
            second_next->prev = first;
        }
        if (head == first)
        {
            head = second;
        }
        else if (head == second)
        {
            head = first;
        }
    }
};

int main()
{
    LinkedList list;
    int value;
    cout << "Enter the Elements of the Linked List Separated by Space:" << endl;
    while (cin >> value)
    {
        list.insert(value);
        if (cin.peek() == '\n')
        {
            break;
        }
    }

    cout << "Linked List Before Swapping:" << endl;
    list.display();

    int value1, value2;

    cout << "Enter the Two Nodes to Swap: ";
    cin >> value1 >> value2;

    list.swap_nodes(value1, value2);

    cout << "Linked List After Swapping:" << endl;
    list.display();

    system("pause");
    return 0;
}

/*
First, I find the two nodes by searching for their values. Then I save the 
previous and next nodes of both nodes. After that, I change the `next` and 
`prev` pointers of the surrounding nodes so the two nodes swap their positions. 
If one of the nodes is the `head`, I update the `head` pointer as well. Since 
the list is circular, I make sure the last node is still connected to the head. 
The values are not swapped; only the links between the nodes are changed.
*/