#include<iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* next;
    Node* prev;
    Node(int value)
    {
        data = value;
        next = NULL;
        prev = NULL;
    }
};
class LinkedList
{
private:
    Node* head;
    Node* tail;
public:
    LinkedList()
    {
        head = NULL;
        tail = NULL;
    }
    void insert(int value)
    {
        Node* new_node = new Node(value);
        if (head == NULL)
        {
            head = new_node;
            tail = new_node;
        }
        else
        {
            tail->next = new_node;
            new_node->prev = tail;
            tail = new_node;
        }
    }
    void display()
    {
        Node* temp = head;
        while (temp != NULL)
        {
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
    void display_backward()
    {
        Node* temp = tail;
        while (temp != NULL)
        {
            cout << temp->data << " <-> ";
            temp = temp->prev;
        }
        cout << "NULL" << endl;
    }
    void merge(LinkedList& list2)
    {
        Node* first = head;
        Node* second = list2.head;

        Node* new_head = NULL;
        Node* new_tail = NULL;
        while (first != NULL && second != NULL)
        {
            Node* selected;
            if (first->data <= second->data)
            {
                selected = first;
                first = first->next;
            }
            else
            {
                selected = second;
                second = second->next;
            }
            selected->prev = new_tail;
            if (new_tail != NULL)
            {
                new_tail->next = selected;
            }
            else
            {
                new_head = selected;
            }
            new_tail = selected;
        }
        while (first != NULL)
        {
            Node* selected = first;
            first = first->next;

            selected->prev = new_tail;
            new_tail->next = selected;
            new_tail = selected;
        }
        while (second != NULL)
        {
            Node* selected = second;
            second = second->next;

            selected->prev = new_tail;
            new_tail->next = selected;
            new_tail = selected;
        }
        head = new_head;
        tail = new_tail;
        if (head != NULL)
        {
            head->prev = NULL;
        }
        if (tail != NULL)
        {
            tail->next = NULL;
        }
        list2.head = NULL;
        list2.tail = NULL;
    }
};

int main()
{
    LinkedList list1;
    LinkedList list2;
    int value;
    cout << "Enter the Elements of the First Sorted Doubly Linked List Separated by Space:" << endl;
    while (cin >> value)
    {
        list1.insert(value);
        if (cin.peek() == '\n')
        {
            break;
        }
    }
    cout << "Enter the Elements of the Second Sorted Doubly Linked List Separated by Space:" << endl;
    while (cin >> value)
    {
        list2.insert(value);
        if (cin.peek() == '\n')
        {
            break;
        }
    }

    cout << "First Sorted Doubly Linked List:" << endl;
    list1.display();

    cout << "Second Sorted Doubly Linked List:" << endl;
    list2.display();

    list1.merge(list2);

    cout << "Result After Merging:" << endl;
    list1.display();

    cout << "Result (Backward):" << endl;
    list1.display_backward();

    system("pause");
    return 0;
}

/*
I use two pointers, one for each sorted doubly linked list. I compare 
the values of the two current nodes and add the smaller one to the merged 
list. While doing this, I update the `next` and `prev` pointers to keep the 
nodes connected correctly. I continue until one of the lists becomes empty, 
and then add the remaining nodes from the other list. At the end, I update 
the `head` and `tail` of the merged list. The existing nodes are reused, so 
no new node is created for each element.
*/