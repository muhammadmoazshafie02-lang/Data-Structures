#include<iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* next;
    Node* prev;
    Node(int value)
    {
        data = value;
        next = NULL;
        prev = NULL;
    }
};
class LinkedList
{
private:
    Node* head;
public:
    LinkedList()
    {
        head = NULL;
    }
    void insert(int value)
    {
        Node* new_node = new Node(value);
        if (head == NULL)
        {
            head = new_node;
        }
        else
        {
            Node* temp = head;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = new_node;
            new_node->prev = temp;
        }
    }
    void display()
    {
        Node* temp = head;
        while (temp != NULL)
        {
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
    void remove_duplicates()
    {
        Node* current = head;
        while (current != NULL && current->next != NULL)
        {
            if (current->data == current->next->data)
            {
                Node* duplicate = current->next;
                current->next = duplicate->next;
                if (duplicate->next != NULL)
                {
                    duplicate->next->prev = current;
                }
                delete duplicate;
            }
            else
            {
                current = current->next;
            }
        }
    }
};

int main()
{
    LinkedList list;
    int value;
    cout << "Enter the Elements of the Linked List Separated by Space:" << endl;
    while (cin >> value)
    {
        list.insert(value);
        if (cin.peek() == '\n')
        {
            break;
        }
    }

    cout << "Doubly Linked List Before Removing Duplicates:" << endl;
    list.display();

    list.remove_duplicates();

    cout << "Doubly Linked List After Removing Duplicates:" << endl;
    list.display();

    system("pause");
    return 0;
}

/*
I go through the doubly linked list using the `current` pointer. At each
node, I check if the next node has the same value. If the values are the same, 
I remove the next node and update its `next` and `prev` pointers to keep the 
list connected properly. I keep doing this until there are no consecutive 
duplicate values left. If the values are different, I simply move to the next 
node.
*/