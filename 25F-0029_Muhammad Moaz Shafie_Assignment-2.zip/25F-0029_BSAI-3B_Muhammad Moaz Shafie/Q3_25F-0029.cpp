#include<iostream>
#include<string>
using namespace std;

class Call
{
public:
    int ID;
    char Skill;
    int Arrival;
    int Duration;
    int Start;
    int Finish;
    int AgentID;
    Call()
    {
        ID = 0;
        Skill = ' ';
        Arrival = 0;
        Duration = 0;
        Start = -1;
        Finish = -1;
        AgentID = -1;
    }
};

class Agent
{
public:
    string Skills;
    int Available;
    Agent()
    {
        Skills = "";
        Available = 0;
    }
    bool CanHandle(char Skill)
    {
        return Skills.find(Skill) != string::npos;
    }
    int SkillCount()
    {
        return Skills.length();
    }
};

class Node
{
public:
    int Data;
    Node* Next;
    Node(int Value)
    {
        Data = Value;
        Next = nullptr;
    }
};

class Queue
{
private:
    Node* Front;
    Node* Rear;
public:
    Queue()
    {
        Front = nullptr;
        Rear = nullptr;
    }
    bool IsEmpty()
    {
        return Front == nullptr;
    }
    void Enqueue(int Value)
    {
        Node* NewNode = new Node(Value);
        if (Rear == nullptr)
        {
            Front = Rear = NewNode;
        }
        else
        {
            Rear->Next = NewNode;
            Rear = NewNode;
        }
    }
    bool Peek(int& Value)
    {
        if (IsEmpty())
        {
            return false;
        }
        Value = Front->Data;
        return true;
    }
    bool Dequeue(int& Value)
    {
        if (IsEmpty())
        {
            return false;
        }
        Node* Temp = Front;
        Value = Temp->Data;
        Front = Front->Next;
        if (Front == nullptr)
        {
            Rear = nullptr;
        }
        delete Temp;
        return true;
    }
    ~Queue()
    {
        while (!IsEmpty())
        {
            int Value;
            Dequeue(Value);
        }
    }
};

class Dispatcher
{
private:
    Agent* Agents;
    Call* Calls;
    int AgentCount;
    int CallCount;
    Queue BQueue, TQueue, SQueue;
    void SortCalls()
    {
        for (int i = 0; i < CallCount - 1; i++)
        {
            for (int j = 0; j < CallCount - i - 1; j++)
            {
                if (Calls[j].Arrival > Calls[j + 1].Arrival || (Calls[j].Arrival == Calls[j + 1].Arrival && Calls[j].ID > Calls[j + 1].ID))
                {
                    Call Temp = Calls[j];
                    Calls[j] = Calls[j + 1];
                    Calls[j + 1] = Temp;
                }
            }
        }
    }
    int CountAgents(char Skill)
    {
        int Count = 0;
        for (int i = 0; i < AgentCount; i++)
        {
            if (Agents[i].CanHandle(Skill))
            {
                Count++;
            }
        }
        return Count;
    }
    Queue* GetQueue(char Skill)
    {
        if (Skill == 'B')
        {
            return &BQueue;
        }
        if (Skill == 'T')
        {
            return &TQueue;
        }
        return &SQueue;
    }
    void AddArrivals(int& Index, int Time)
    {
        while (Index < CallCount && Calls[Index].Arrival <= Time)
        {
            GetQueue(Calls[Index].Skill)->Enqueue(Index);
            Index++;
        }
    }
    bool GetBestAssignment(int Time, int& AgentIndex, int& CallIndex)
    {
        AgentIndex = -1;
        CallIndex = -1;
        int BestRarity = 1000;
        int BestSkills = 1000;
        char Skills[3] = { 'B', 'T', 'S' };
        for (int i = 0; i < 3; i++)
        {
            int Index;
            if (!GetQueue(Skills[i])->Peek(Index))
            {
                continue;
            }
            int Rarity = CountAgents(Skills[i]);
            for (int j = 0; j < AgentCount; j++)
            {
                if (Agents[j].Available <= Time && Agents[j].CanHandle(Skills[i]))
                {
                    int SkillCount = Agents[j].SkillCount();
                    if (Rarity < BestRarity || (Rarity == BestRarity && SkillCount < BestSkills) || (Rarity == BestRarity && SkillCount == BestSkills && (AgentIndex == -1 || j < AgentIndex)))
                    {
                        BestRarity = Rarity;
                        BestSkills = SkillCount;
                        AgentIndex = j;
                        CallIndex = Index;
                    }
                }
            }
        }
        return AgentIndex != -1;
    }

public:
    Dispatcher(int A, int C)
    {
        AgentCount = A;
        CallCount = C;
        Agents = new Agent[A];
        Calls = new Call[C];
    }
    void Input()
    {
        cout << ">> Enter Skills of Each Agent:" << endl;
        for (int i = 0; i < AgentCount; i++)
        {
            string Name;
            cin >> Name >> Agents[i].Skills;
        }
        cout << ">> Enter (ID Skill Arrival Duration) for Each Call:" << endl;
        for (int i = 0; i < CallCount; i++)
        {
            cin >> Calls[i].ID >> Calls[i].Skill >> Calls[i].Arrival >> Calls[i].Duration;
        }
        SortCalls();
    }
    void Schedule()
    {
        int Index = 0;
        int Completed = 0;
        int Time = 0;
        while (Completed < CallCount)
        {
            AddArrivals(Index, Time);
            int AgentIndex, CallIndex;
            bool Assigned = false;
            while (GetBestAssignment(Time, AgentIndex, CallIndex))
            {
                int Value;
                GetQueue(Calls[CallIndex].Skill)->Dequeue(Value);
                Calls[CallIndex].Start = Time;
                Calls[CallIndex].Finish = Time + Calls[CallIndex].Duration;
                Calls[CallIndex].AgentID = AgentIndex + 1;
                Agents[AgentIndex].Available = Calls[CallIndex].Finish;
                cout << "Call " << Calls[CallIndex].ID << " (" << Calls[CallIndex].Skill << "): Agent A" << AgentIndex + 1 << ", Arrives " << Calls[CallIndex].Arrival << ", Starts " << Calls[CallIndex].Start << ", Ends " << Calls[CallIndex].Finish << endl;
                Completed++;
                Assigned = true;
            }
            if (Completed == CallCount)
            {
                break;
            }
            int NextTime = 2147483647;
            if (Index < CallCount && Calls[Index].Arrival < NextTime)
            {
                NextTime = Calls[Index].Arrival;
            }
            for (int i = 0; i < AgentCount; i++)
            {
                if (Agents[i].Available > Time && Agents[i].Available < NextTime)
                {
                    NextTime = Agents[i].Available;
                }
            }
            if (NextTime == 2147483647)
            {
                cout << "Unable to Schedule Remaining Calls" << endl;
                return;
            }
            Time = NextTime;
        }
    }
    void Verify()
    {
        for (int i = 0; i < CallCount; i++)
        {
            if (Calls[i].Start < Calls[i].Arrival || Calls[i].AgentID < 1 || Calls[i].AgentID > AgentCount || !Agents[Calls[i].AgentID - 1].CanHandle(Calls[i].Skill))
            {
                cout << "Verification: FAILED - Rule 1" << endl;
                return;
            }
        }
        for (int i = 0; i < CallCount; i++)
        {
            for (int j = i + 1; j < CallCount; j++)
            {
                if (Calls[i].AgentID == Calls[j].AgentID && Calls[i].Start < Calls[j].Finish && Calls[j].Start < Calls[i].Finish)
                {
                    cout << "Verification: FAILED - Rule 2" << endl;
                    return;
                }
            }
        }
        for (int i = 0; i < CallCount; i++)
        {
            for (int j = 0; j < CallCount; j++)
            {
                if (Calls[i].Skill == Calls[j].Skill && (Calls[i].Arrival < Calls[j].Arrival || (Calls[i].Arrival == Calls[j].Arrival && Calls[i].ID < Calls[j].ID)) && Calls[i].Start > Calls[j].Start)
                {
                    cout << "Verification: FAILED - Rule 3" << endl;
                    return;
                }
            }
        }
        for (int i = 0; i < AgentCount; i++)
        {
            int PreviousFinish = 0;
            for (int j = 0; j < CallCount; j++)
            {
                int NextStart = 2147483647;
                int NextCall = -1;
                for (int k = 0; k < CallCount; k++)
                {
                    if (Calls[k].AgentID == i + 1 && Calls[k].Start >= PreviousFinish && Calls[k].Start < NextStart)
                    {
                        NextStart = Calls[k].Start;
                        NextCall = k;
                    }
                }
                if (NextCall == -1)
                {
                    NextStart = 2147483647;
                }
                for (int k = 0; k < CallCount; k++)
                {
                    if (Agents[i].CanHandle(Calls[k].Skill) && Calls[k].Arrival < NextStart && Calls[k].Start > PreviousFinish && Calls[k].Start > Calls[k].Arrival && Calls[k].Arrival < Calls[k].Start)
                    {
                        if (Calls[k].Arrival < NextStart && Calls[k].Start > PreviousFinish)
                        {
                            cout << "Verification: FAILED - Rule 4" << endl;
                            return;
                        }
                    }
                }
                if (NextCall == -1)
                {
                    break;
                }
                PreviousFinish = Calls[NextCall].Finish;
                Calls[NextCall].AgentID = -Calls[NextCall].AgentID;
            }
            for (int j = 0; j < CallCount; j++)
            {
                if (Calls[j].AgentID < 0)
                {
                    Calls[j].AgentID = -Calls[j].AgentID;
                }
            }
        }
        cout << "Verification: PASSED" << endl;
    }
    void Results()
    {
        int MaxWait = 0;
        int TotalWait = 0;
        int FinishTime = 0;
        for (int i = 0; i < CallCount; i++)
        {
            int Wait = Calls[i].Start - Calls[i].Arrival;
            if (Wait > MaxWait)
            {
                MaxWait = Wait;
            }
            TotalWait = TotalWait + Wait;
            if (Calls[i].Finish > FinishTime)
            {
                FinishTime = Calls[i].Finish;
            }
        }
        cout << "Maximum Wait: " << MaxWait << " | Average Wait: ";
        if (CallCount > 0)
        {
            cout.setf(ios::fixed);
            cout.precision(2);
            cout << (double)TotalWait / CallCount;
        }
        else
        {
            cout << "0.00";
        }
        cout << " | Finish time: " << FinishTime << endl;
    }
    ~Dispatcher()
    {
        delete[] Agents;
        delete[] Calls;
    }
};

int main()
{
    int A, C;
    cout << ">> Enter Number of Agents: ";
    cin >> A;
    cout << ">> Enter Number of Calls: ";
    cin >> C;
    if (A <= 0 || C < 0)
    {
        cout << "Invalid Input" << endl;
        return 0;
    }
    Dispatcher D(A, C);
    D.Input();
    D.Schedule();
    D.Results();
    D.Verify();

	system("pause");
    return 0;
}