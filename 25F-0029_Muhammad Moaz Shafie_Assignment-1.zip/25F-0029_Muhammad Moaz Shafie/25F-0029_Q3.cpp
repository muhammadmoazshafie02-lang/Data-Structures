#include<iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* next;
    Node(int value)
    {
        data = value;
        next = NULL;
    }
};
class LinkedList
{
private:
    Node* head;
public:
    LinkedList()
    {
        head = NULL;
    }
    void insert(int value)
    {
        Node* new_node = new Node(value);
        if (head == NULL)
        {
            head = new_node;
        }
        else
        {
            Node* temp = head;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = new_node;
        }
    }
    void display()
    {
        Node* temp = head;
        while (temp != NULL)
        {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
    void rearrange()
    {
        if (head == NULL || head->next == NULL)
        {
            return;
        }
        Node* first = head;
        while (first != NULL && first->next != NULL)
        {
            Node* previous = first;
            Node* last = first->next;
            while (last->next != NULL)
            {
                previous = last;
                last = last->next;
            }
            if (first->next == last)
            {
                break;
            }
            previous->next = NULL;

            Node* nextFirst = first->next;

            first->next = last;
            last->next = nextFirst;

            first = nextFirst;
        }
    }
};

int main()
{
    LinkedList list;
    int value;
    cout << "Enter the Elements of the Linked List Separated by Space: " << endl;
    while (cin >> value)
    {
        list.insert(value);
        if (cin.peek() == '\n')
        {
            break;
        }
    }
    cout << "Linked List Before Rearrangement: " << endl;
    list.display();

    list.rearrange();

    cout << "Linked List After Rearrangement: " << endl;
    list.display();

    system("pause");
    return 0;
}

/*
I keep the first node at its place and find the last node of the list. 
Then I remove the last node by changing the `next` pointer of the previous 
node and connect it after the first node. I repeat this process for the 
next nodes. This rearranges the list in the order of first, last, second, 
second-last, and so on. The node values are not changed; only the `next` 
pointers are updated.
*/