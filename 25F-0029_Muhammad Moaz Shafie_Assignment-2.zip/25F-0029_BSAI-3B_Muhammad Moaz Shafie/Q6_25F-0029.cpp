#include<iostream>
#include<string>
using namespace std;

template<class T>
class Node
{
public:
    T Data;
    Node* Next;
    Node(T Value)
    {
        Data = Value;
        Next = nullptr;
    }
};

template<class T>
class Stack
{
private:
    Node<T>* TopNode;
public:
    Stack()
    {
        TopNode = nullptr;
    }
    bool Push(T Data)
    {
        Node<T>* NewNode = new Node<T>(Data);
        NewNode->Next = TopNode;
        TopNode = NewNode;
        return true;
    }
    bool Pop(T& Data)
    {
        if (TopNode == nullptr)
        {
            return false;
        }
        Node<T>* Temp = TopNode;
        Data = Temp->Data;
        TopNode = TopNode->Next;
        delete Temp;
        return true;
    }
    bool IsEmpty()
    {
        return TopNode == nullptr;
    }
    ~Stack()
    {
        while (TopNode != nullptr)
        {
            Node<T>* Temp = TopNode;
            TopNode = TopNode->Next;
            delete Temp;
        }
    }
};

bool IsBalanced(string S)
{
    Stack<string> St;
    char Quote = '\0';
    bool InComment = false;
    for (int i = 0; i < S.length(); i++)
    {
        if (InComment)
        {
            if (S[i] == '*' && i + 1 < S.length() && S[i + 1] == '/')
            {
                string Temp;
                St.Pop(Temp);
                InComment = false;
                i++;
            }
            continue;
        }
        if (Quote != '\0')
        {
            if (S[i] == Quote)
            {
                Quote = '\0';
            }
            continue;
        }
        if (S[i] == '/' && i + 1 < S.length() && S[i + 1] == '*')
        {
            St.Push("/*");
            InComment = true;
            i++;
        }
        else if (S[i] == '\'' || S[i] == '"')
        {
            Quote = S[i];
        }
        else if (S[i] == '(' || S[i] == '{' || S[i] == '[' || S[i] == '<')
        {
            string Temp(1, S[i]);
            St.Push(Temp);
        }
        else if (S[i] == ')' || S[i] == '}' || S[i] == ']' || S[i] == '>')
        {
            string Temp;
            if (!St.Pop(Temp))
            {
                return false;
            }
            if ((S[i] == ')' && Temp != "(") || (S[i] == '}' && Temp != "{") || (S[i] == ']' && Temp != "[") || (S[i] == '>' && Temp != "<"))
            {
                return false;
            }
        }
    }
    return St.IsEmpty() && Quote == '\0' && !InComment;
}

int main()
{
    string S;
    cout << "Enter String: ";
    getline(cin, S);
    if (IsBalanced(S))
    {
        cout << "True" << endl;
    }
    else
    {
        cout << "False" << endl;
    }

	system("pause");
    return 0;
}