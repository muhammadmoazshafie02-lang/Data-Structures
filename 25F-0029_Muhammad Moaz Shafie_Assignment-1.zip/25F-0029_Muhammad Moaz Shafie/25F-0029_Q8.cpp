#include<iostream>
#include<string>
using namespace std;
class Node
{
public:
    int data;
    Node* next;
    Node* prev;
    Node(int value)
    {
        data = value;
        next = NULL;
        prev = NULL;
    }
};
class LinkedList
{
private:
    Node* head;
    Node* tail;
public:
    LinkedList()
    {
        head = NULL;
        tail = NULL;
    }
    void insert(int value)
    {
        Node* new_node = new Node(value);
        if (head == NULL)
        {
            head = new_node;
            tail = new_node;
        }
        else
        {
            tail->next = new_node;
            new_node->prev = tail;
            tail = new_node;
        }
    }
    void insert_number(string number)
    {
        for (int i = 0; i < number.length(); i++)
        {
            insert(number[i] - '0');
        }
    }
    void display()
    {
        Node* temp = head;
        while (temp != NULL)
        {
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
    int count_nodes()
    {
        int count = 0;
        Node* temp = head;
        while (temp != NULL)
        {
            count++;
            temp = temp->next;
        }
        return count;
    }
    bool is_smaller(LinkedList& list)
    {
        int count1 = count_nodes();
        int count2 = list.count_nodes();
        if (count1 != count2)
        {
            return count1 < count2;
        }
        Node* first = head;
        Node* second = list.head;
        while (first != NULL)
        {
            if (first->data != second->data)
            {
                return first->data < second->data;
            }
            first = first->next;
            second = second->next;
        }
        return false;
    }
    LinkedList subtract(LinkedList& list)
    {
        LinkedList result;
        Node* first;
        Node* second;
        if (is_smaller(list))
        {
            first = list.tail;
            second = tail;
        }
        else
        {
            first = tail;
            second = list.tail;
        }
        int borrow = 0;
        while (first != NULL)
        {
            int digit1 = first->data - borrow;
            int digit2 = 0;
            if (second != NULL)
            {
                digit2 = second->data;
            }
            if (digit1 < digit2)
            {
                digit1 = digit1 + 10;
                borrow = 1;
            }
            else
            {
                borrow = 0;
            }
            int difference = digit1 - digit2;
            Node* new_node = new Node(difference);
            if (result.head == NULL)
            {
                result.head = new_node;
                result.tail = new_node;
            }
            else
            {
                new_node->next = result.head;
                result.head->prev = new_node;
                result.head = new_node;
            }
            first = first->prev;
            if (second != NULL)
            {
                second = second->prev;
            }
        }
        while (result.head != NULL && result.head->data == 0 && result.head->next != NULL)
        {
            Node* temp = result.head;
            result.head = result.head->next;
            result.head->prev = NULL;
            delete temp;
        }
        return result;
    }
};

int main()
{
    LinkedList first_number;
    LinkedList second_number;

    string first;
    string second;

    cout << "Enter the First Number: ";
    cin >> first;

    cout << "Enter the Second Number: ";
    cin >> second;

    first_number.insert_number(first);
    second_number.insert_number(second);

    cout << "First Number: ";
    first_number.display();

    cout << "Second Number: ";
    second_number.display();

    LinkedList result = first_number.subtract(second_number);

    cout << "Result After Subtraction: ";
    result.display();

    system("pause");
    return 0;
}

/*
I store each digit of the number in a separate node of the doubly linked list. 
First, I compare the lengths of both numbers, and if they are the same, I compare 
their digits to find the smaller number. I start the subtraction from the last 
node because subtraction is done from right to left. Using the `prev` pointer, I 
move backwards and handle borrowing when needed. Each calculated digit is stored 
in the result list. At the end, I remove extra zeros from the beginning, but keep 
one zero if the result is zero.
*/